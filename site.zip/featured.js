(() => {
  'use strict';
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const track = document.querySelector('.waydoo-gallery-track');
  if (track) {
    const previous = document.querySelector('[data-waydoo-direction="previous"]');
    const next = document.querySelector('[data-waydoo-direction="next"]');
    const update = () => {
      previous.disabled = track.scrollLeft <= 2;
      next.disabled = track.scrollLeft + track.clientWidth >= track.scrollWidth - 3;
    };
    const move = direction => track.scrollBy({left:direction * track.clientWidth,behavior:reduced.matches ? 'instant' : 'smooth'});
    previous.addEventListener('click',()=>move(-1)); next.addEventListener('click',()=>move(1));
    track.addEventListener('scroll',update,{passive:true}); window.addEventListener('resize',update); update();
  }
  const video = document.querySelector('#waydoo-film');
  if (!video) return;
  const source = video.querySelector('source');
  let loaded = false, visible = false, wantsPlayback = !reduced.matches;
  const load = () => {
    if (loaded) return;
    source.src = source.dataset.src; video.load(); loaded = true;
  };
  const sync = () => {
    const dialogOpen = !!document.querySelector('dialog[open]');
    if (visible && !document.hidden && !dialogOpen) {
      load();
      if (wantsPlayback) video.play().catch(()=>{});
    } else video.pause();
  };
  new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;sync();},{threshold:.15}).observe(video);
  video.addEventListener('play',()=>{wantsPlayback=true;});
  video.addEventListener('pause',()=>{
    if(visible && !document.hidden && !document.querySelector('dialog[open]')) wantsPlayback=false;
  });
  video.addEventListener('pointerdown',load,{once:true});
  video.addEventListener('keydown',load,{once:true});
  document.addEventListener('visibilitychange',sync);
  new MutationObserver(sync).observe(document.body,{subtree:true,attributes:true,attributeFilter:['open']});
  reduced.addEventListener('change',()=>{wantsPlayback=!reduced.matches;if(reduced.matches)video.pause();else sync();});
})();
