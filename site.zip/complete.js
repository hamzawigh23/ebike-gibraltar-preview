(() => {
  'use strict';
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const dropdowns = $$('.nav-dropdown');
  dropdowns.forEach(item => item.addEventListener('toggle', () => {
    if (item.open) dropdowns.forEach(other => { if (other !== item) other.open = false; });
  }));
  document.addEventListener('click', e => {
    if (!e.target.closest('.nav-dropdown')) dropdowns.forEach(item => item.open = false);
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') dropdowns.forEach(item => item.open = false);
  });
  $$('[data-offer-filter]').forEach(button => button.addEventListener('click', () => {
    $$('[data-offer-filter]').forEach(b => {
      b.classList.toggle('active', b === button);
      b.setAttribute('aria-pressed', String(b === button));
    });
    const filter = button.dataset.offerFilter;
    $$('[data-offer-category]').forEach(card => card.hidden = filter !== 'all' && card.dataset.offerCategory !== filter);
    if ($('#no-offers')) $('#no-offers').hidden = $$('[data-offer-category]').some(card => !card.hidden);
  }));
  const voices = $('.voices'), pause = $('#pause-reviews'), expand = $('#expand-reviews');
  if (voices && pause && expand) {
    pause.addEventListener('click', () => {
      const paused = voices.classList.toggle('reviews-paused');
      pause.setAttribute('aria-pressed', String(paused));
      pause.querySelector('span').textContent = paused ? 'Play reviews' : 'Pause reviews';
      pause.querySelector('use').setAttribute('href', paused ? '#i-play' : '#i-pause');
    });
    expand.addEventListener('click', () => {
      const expanded = voices.classList.toggle('reviews-expanded');
      expand.setAttribute('aria-expanded', String(expanded));
      expand.textContent = expanded ? 'Back to moving reviews' : 'Read all 6 reviews';
      pause.hidden = expanded;
    });
  }
  const form = $('#contact-form');
  if (form) {
    const query = new URLSearchParams(location.search).get('interest');
    const interestMap = {'private-tour':'Private group tour','rock-away':'Rock Away Tours','rock-eco-tour':'Rock the Eco Tour','ecargo-rental':'eCargo rental or subscription','delivery-efree':'eCargo rental or subscription','waydoo':'Waydoo eFoil','buying':'Buying an eBike','test-ride':'Test ride','workshop':'Workshop consultation','bike-consultation':'Buying an eBike'};
    if (interestMap[query]) form.elements.interest.value = interestMap[query];
    const date = new Date();
    form.elements.date.min = [date.getFullYear(),String(date.getMonth()+1).padStart(2,'0'),String(date.getDate()).padStart(2,'0')].join('-');
    let draft = '';
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const values = new FormData(form);
      const clean = key => String(values.get(key) || '').trim();
      draft = `Hello EBike Gibraltar,\n\nI’m interested in: ${clean('interest')}\nName: ${clean('name')}\nEmail: ${clean('email')}${clean('date') ? '\nPreferred date: '+clean('date') : ''}${clean('riders') ? '\nNumber of riders: '+clean('riders') : ''}\n\n${clean('message')}\n\nThank you,\n${clean('name')}`;
      $('#enquiry-preview').textContent = draft;
      $('#enquiry-mailto').href = `mailto:info@ebike-gibraltar.com?subject=${encodeURIComponent('Enquiry: '+clean('interest'))}&body=${encodeURIComponent(draft)}`;
      $('#enquiry-result').hidden = false;
      form.hidden = true;
      $('#enquiry-status').textContent = 'Your message has not been sent yet.';
      $('#enquiry-mailto').focus({preventScroll:true});
    });
    $('#edit-enquiry').addEventListener('click', () => {
      $('#enquiry-result').hidden = true; form.hidden = false; form.elements.message.focus({preventScroll:true});
    });
    $('#copy-enquiry').addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(draft);
        $('#enquiry-status').textContent = 'Copied. Paste it into an email to info@ebike-gibraltar.com and send when ready.';
      } catch {
        const range = document.createRange(); range.selectNodeContents($('#enquiry-preview'));
        const selection = window.getSelection(); selection.removeAllRanges(); selection.addRange(range);
        $('#enquiry-status').textContent = 'Message selected. Use your device’s Copy command, then paste it into your email app.';
      }
    });
  }
  const search = $('#product-search'), category = $('#product-category');
  if (search && category) {
    const requested = new URLSearchParams(location.search).get('category');
    if ([...category.options].some(option => option.value === requested)) category.value = requested;
    const cards = $$('.product-card');
    const filterProducts = () => {
      const query = search.value.trim().toLowerCase(); let count = 0;
      cards.forEach(card => {
        const categories = JSON.parse(card.dataset.productCategories);
        const matches = (card.dataset.productName+' '+categories.join(' ')).toLowerCase().includes(query) && (category.value === 'all' || categories.includes(category.value));
        card.hidden = !matches; if(matches) count++;
      });
      $('#product-count').textContent = `${count} ${count === 1 ? 'result' : 'results'}`;
      $('#no-products').hidden = count > 0;
    };
    search.addEventListener('input', filterProducts); category.addEventListener('change', filterProducts); filterProducts();
  }
  const board = $('#leaderboard-data');
  if (board) {
    const groups = JSON.parse(board.textContent);
    const groupSelect = $('#leader-group'), categorySelect = $('#leader-category');
    const updateRows = () => {
      const selected = groups[Number(groupSelect.value)]?.categories[Number(categorySelect.value)];
      const rows = selected?.rows || [];
      $('#leader-rows').replaceChildren(...rows.map(row => {
        const tr = document.createElement('tr');
        row.forEach(value => { const cell = document.createElement('td'); cell.textContent = value || '—'; tr.append(cell); });
        return tr;
      }));
      $('#leader-empty').hidden = rows.length > 0;
      $('#leader-empty').textContent = selected?.checked ? 'No published results in this category yet.' : 'This category could not be loaded. Check the original leaderboard for its records.';
      $('#leader-source').href = selected?.url || groups[Number(groupSelect.value)]?.url || 'https://ebike-gibraltar.com/rock-to-the-top-challenge.php';
    };
    const updateCategories = () => {
      categorySelect.replaceChildren(...(groups[Number(groupSelect.value)]?.categories || []).map((category,index) => {
        const option = document.createElement('option'); option.value = String(index); option.textContent = category.name; return option;
      }));
      updateRows();
    };
    groupSelect.addEventListener('change',updateCategories);categorySelect.addEventListener('change',updateRows);updateCategories();
  }
})();
