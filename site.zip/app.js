'use strict';
(() => {
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const icon = (name) => `<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;
  const tours = {
    top: { title: 'Rock to<br>the Top.', type: 'GUIDED ADVENTURE', price: '£85', unit: 'per person', duration: '3.5 hours', image: 'assets/rock.webp', alt: 'The Rock of Gibraltar', description: 'A guided ride taking in Gibraltar’s coast and Upper Rock. The published price includes Nature Reserve entry. Pre-booking is required.', inclusions: ['Premium eBike', 'Helmet & briefing', 'Local guide', 'Nature Reserve entry'], url: 'https://ebike-gibraltar.com/tours/small-group-guided-tour---rock-to-the-top.php' },
    coast: { title: 'Around<br>the Rock.', type: 'GUIDED COASTAL EXPLORER', price: '£64', unit: 'per person', duration: '2.5 hours', image: 'assets/lighthouse.webp', alt: 'Europa Point Lighthouse', description: 'Explore the lower Rock, waterfront and Europa Point with an official guide. A panoramic coastal loop, rather than an Upper Rock tour. Pre-booking is required.', inclusions: ['Premium eBike', 'Helmet & briefing', 'Local guide', 'Mineral water'], url: 'https://ebike-gibraltar.com/tours/small-group-guided-tour---rock-around-gibraltar.php' },
    rental: { title: 'Your pace.<br>Your ride.', type: 'SELF-GUIDED EXPLORING', price: 'From £20', unit: 'hourly rental', duration: 'Flexible', image: 'assets/cycling.webp', alt: 'A rider on a Riese & Müller eBike', description: 'Make your own plans with an hourly rental from £20, or a half-day rental from £35. Follow the operator’s cycle maps or self-guiding app. Confirm rental duration, inclusions and any attraction-entry costs with the team.', inclusions: ['Premium eBike', 'Hourly or half-day options', 'Cycle maps available'], url: 'https://ebike-gibraltar.com/tours/ebike-rental---by-the-hour.php' }
  };
  const booking = $('#booking-dialog');
  const finder = $('#finder-dialog');
  function openDialog(dialog) {
    $$('dialog[open]').forEach(d => d.close());
    dialog.showModal();
    document.body.classList.add('modal-open');
  }
  $$('dialog').forEach(dialog => {
    dialog.addEventListener('close', () => {
      if (!$('dialog[open]')) document.body.classList.remove('modal-open');
    });
    dialog.addEventListener('click', event => {
      if (event.target !== dialog) return;
      const r = dialog.getBoundingClientRect();
      if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) dialog.close();
    });
    $$('[data-close]', dialog).forEach(b => b.addEventListener('click', () => dialog.close()));
  });
  function chooseTour(key) {
    const t = tours[key] || tours.top;
    $('#booking-image-title').innerHTML = t.title;
    $('#booking-type').textContent = t.type;
    $('#booking-image').src = t.image;
    $('#booking-image').alt = t.alt;
    $('#booking-price').textContent = t.price;
    $('#booking-unit').textContent = t.unit;
    $('#booking-duration').textContent = t.duration;
    $('#booking-description').textContent = t.description;
    $('#booking-inclusions').innerHTML = t.inclusions.map(s => `<span>${icon('check')}${s}</span>`).join('');
    $('#official-details').href = t.url;
    $$('[data-choice]').forEach(b => {
      const selected = b.dataset.choice === key;
      b.classList.toggle('selected', selected);
      b.setAttribute('aria-pressed', String(selected));
    });
  }
  function showTour(key) { chooseTour(key); openDialog(booking); }
  $$('[data-book]').forEach(b => b.addEventListener('click', () => showTour(b.dataset.book)));
  $$('[data-tour]').forEach(b => b.addEventListener('click', () => showTour(b.dataset.tour)));
  $$('[data-choice]').forEach(b => b.addEventListener('click', () => chooseTour(b.dataset.choice)));
  $$('[data-filter]').forEach(b => b.addEventListener('click', () => {
    const filter = b.dataset.filter;
    $$('[data-filter]').forEach(f => { f.classList.toggle('active', f === b); f.setAttribute('aria-pressed', String(f === b)); });
    $$('.tour-card').forEach(card => { card.hidden = filter !== 'all' && card.dataset.category !== filter; });
  }));
  const views = {
    rock: { image: 'assets/rock.webp', alt: 'The limestone ridge and views from the Upper Rock of Gibraltar', title: 'A whole new<br>high point.', description: 'Explore the Upper Rock on the Rock to the Top guided tour.', place: 'THE UPPER ROCK' },
    lighthouse: { image: 'assets/lighthouse.webp', alt: 'Europa Point Lighthouse with North Africa in the distance', title: 'Look a little<br>further.', description: 'Stop at Europa Point on the coastal guided ride around Gibraltar.', place: 'EUROPA POINT' },
    coast: { image: 'assets/coast.webp', alt: 'A scenic coastal road below the Rock of Gibraltar', title: 'The long way.<br>The lovely way.', description: 'Take in Mediterranean scenery along Gibraltar’s eastern coastline.', place: 'THE MEDITERRANEAN COAST' }
  };
  $$('[data-view]').forEach(b => b.addEventListener('click', () => {
    const v = views[b.dataset.view];
    if (!v) return;
    $('#landscape-image').src = v.image;
    $('#landscape-image').alt = v.alt;
    $('#landscape-title').innerHTML = v.title;
    $('#landscape-description').textContent = v.description;
    $('#landscape-place').textContent = v.place;
    $$('[data-view]').forEach(x => { x.classList.toggle('active', x === b); x.setAttribute('aria-pressed', String(x === b)); });
  }));
  const finderForm = $('#finder-form');
  const finderResult = $('#finder-result');
  function resetFinder() { finderForm.hidden = false; finderResult.hidden = true; finderResult.replaceChildren(); }
  $$('[data-open-finder]').forEach(b => b.addEventListener('click', () => { resetFinder(); openDialog(finder); }));
  function finderResponse(label, title, copy, tour, cta) {
    finderResult.innerHTML = `<span class="result-label">${label}</span><h3>${title}</h3><p>${copy}</p>`;
    const action = document.createElement(tour ? 'button' : 'a');
    action.className = 'button dark full';
    action.innerHTML = cta + icon('up');
    if (tour) action.addEventListener('click', () => showTour(tour));
    else action.href = 'mailto:info@ebike-gibraltar.com?subject=Help%20choosing%20a%20suitable%20eBike%20experience';
    finderResult.append(action);
    const again = document.createElement('button');
    again.className = 'text-button'; again.textContent = 'Try again';
    again.addEventListener('click', resetFinder); finderResult.append(again);
    finderForm.hidden = true; finderResult.hidden = false; action.focus();
  }
  finderForm.addEventListener('submit', event => {
    event.preventDefault();
    const data = new FormData(finderForm);
    if (data.get('confidence') === 'no') {
      finderResponse('LET’S CHECK TOGETHER', 'Talk to the team first.', 'These rides can share roads with traffic. Electric assistance does not replace cycling confidence, so we will not automatically recommend a tour. Ask the team about suitability before paying for a ride.', null, 'Ask about suitability');
    } else if (data.get('style') === 'solo') {
      finderResponse('A GOOD STARTING POINT', 'Your pace. Your own plans.', 'An independent eBike rental may fit your plans. Hourly rentals start from £20; half-day rentals from £35. Confirm your route, return time and rider requirements with the operator.', 'rental', 'Explore eBike rental');
    } else if (data.get('time') === 'short') {
      finderResponse('LET’S WORK AROUND YOUR TIME', 'A shorter visit?', 'The shortest of the two featured guided tours is 2.5 hours, before allowing for travel to and from the store. Ask the team what could fit your schedule rather than booking a ride that is too long.', null, 'Ask the local team');
    } else if (data.get('time') === 'coast') {
      finderResponse('YOUR COASTAL MATCH', 'Rock Around Gibraltar.', 'A 2.5-hour guided ride around the lower Rock, with Europa Point and Mediterranean views. Listed at £64 per person. Remember to allow time outside the tour for your onward travel.', 'coast', 'Explore the coastal ride');
    } else {
      finderResponse('YOUR UPPER ROCK MATCH', 'Rock to the Top.', 'A 3.5-hour guided adventure with Upper Rock panoramas. Listed at £85 per person including Nature Reserve entry. Confirm rider requirements and availability with the operator.', 'top', 'Explore Rock to the Top');
    }
  });
  const menuButton = $('.menu-toggle'), mobileNav = $('#mobile-nav');
  function closeMenu() { mobileNav.hidden = true; menuButton.setAttribute('aria-expanded', 'false'); menuButton.setAttribute('aria-label', 'Open navigation'); }
  menuButton.addEventListener('click', () => { const open = mobileNav.hidden; mobileNav.hidden = !open; menuButton.setAttribute('aria-expanded', String(open)); menuButton.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation'); });
  $$('a', mobileNav).forEach(a => a.addEventListener('click', closeMenu));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu(); });
  window.addEventListener('resize', () => { if (innerWidth > 740) closeMenu(); });
  const header = $('.header'), mobileBook = $('.mobile-book');
  let scheduled = false;
  window.addEventListener('scroll', () => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => { header.classList.toggle('scrolled', scrollY > 20); mobileBook.classList.toggle('visible', scrollY > 600); scheduled = false; });
  }, { passive: true });
  const filmDialog = $('#film-dialog'), film = $('#ride-film');
  $$('[data-open-film]').forEach(button => button.addEventListener('click', () => {
    if (!film.getAttribute('src')) film.src = 'assets/ride-film.mp4';
    openDialog(filmDialog);
    const play = film.play(); if (play && play.catch) play.catch(() => {});
  }));
  filmDialog.addEventListener('close', () => { film.pause(); film.currentTime = 0; });
  // No analytics, trackers, third-party booking embed, cookies, or automatic email sending.
})();
