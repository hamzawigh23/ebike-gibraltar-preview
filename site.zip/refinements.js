/*
 * Progressive enhancement for EBike's existing HTML; no framework migration.
 * Liquid-metal material: Paper Shaders (Apache-2.0), as used by
 * johuniq / Joly UI's Liquid Metal Button. See assets/licenses/.
 */
(() => {
  'use strict';
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const mounts = new Map();
  const pending = new Set();
  let shaderPromise;
  const selector = '.button, .card-link, .mobile-book > button';
  const loadShader = () => shaderPromise ||= Promise.all([
    import('./vendor/paper-shaders/shader-mount.js'),
    import('./vendor/paper-shaders/shaders/liquid-metal.js'),
    import('./vendor/paper-shaders/empty-pixel.js').then(async ({ emptyPixel }) => {
      const image = new Image(); image.src = emptyPixel; await image.decode(); return image;
    })
  ]);

  function dispose(button) {
    const mount = mounts.get(button);
    if (mount) { mount.dispose(); mounts.delete(button); }
    button.querySelector('.metal-shader')?.remove();
    button.classList.remove('metal-has-shader');
  }
  async function mountMetal(button) {
    if (reduced.matches || mounts.has(button) || pending.has(button)) return;
    pending.add(button);
    let host;
    try {
      const [{ ShaderMount }, { liquidMetalFragmentShader }, emptyImage] = await loadShader();
      if (!button.isConnected || !button.classList.contains('effects-visible') || reduced.matches) return;
      host = document.createElement('span');
      host.className = 'metal-shader'; host.setAttribute('aria-hidden', 'true');
      button.prepend(host);
      const green = button.classList.contains('lime');
      const mount = new ShaderMount(host, liquidMetalFragmentShader, {
        u_image: emptyImage,
        u_colorBack: [0.16, 0.21, 0.19, 1],
        u_colorTint: green ? [0.66, 0.86, 0.38, 0.55] : [0.16, 0.67, 0.82, 0.5],
        u_repetition: 4, u_softness: 0.5, u_shiftRed: 0.12, u_shiftBlue: 0.18,
        u_distortion: 0.08, u_contour: 0.25, u_angle: 45, u_scale: 1,
        u_shape: 0, u_isImage: false, u_offsetX: 0.1, u_offsetY: -0.1,
        u_originX: 0.5, u_originY: 0.5, u_worldWidth: 0, u_worldHeight: 0,
        u_fit: 2, u_rotation: 0, u_imageAspectRatio: 1
      }, { alpha: true, antialias: false }, 0.35, 0, 1, 120000);
      host.querySelector('canvas')?.setAttribute('aria-hidden', 'true');
      mounts.set(button, mount);
      button.classList.add('metal-has-shader');
    } catch {
      host?.remove(); // The CSS metal rim remains available without WebGL.
    } finally { pending.delete(button); }
  }

  const observer = new IntersectionObserver(entries => {
    entries.forEach(({ target, isIntersecting }) => {
      target.classList.toggle('effects-visible', isIntersecting);
      if (!target.classList.contains('metal-button')) return;
      if (isIntersecting) mountMetal(target); else dispose(target);
    });
  }, { threshold: 0.05 });

  function enhance(button) {
    if (button.classList.contains('metal-button')) return;
    button.classList.add('metal-button');
    // A stable label layer stays readable throughout all animation states.
    const label = document.createElement('span'); label.className = 'metal-label';
    while (button.firstChild) label.append(button.firstChild);
    button.append(label);
    button.addEventListener('pointerenter', () => mounts.get(button)?.setSpeed(reduced.matches ? 0 : 0.8));
    button.addEventListener('pointerleave', () => mounts.get(button)?.setSpeed(reduced.matches ? 0 : 0.35));
    button.addEventListener('click', event => {
      if (reduced.matches) return;
      const box = button.getBoundingClientRect();
      const ripple = document.createElement('span'); ripple.className = 'metal-ripple';
      ripple.setAttribute('aria-hidden', 'true');
      ripple.style.left = `${event.detail ? event.clientX - box.left : box.width / 2}px`;
      ripple.style.top = `${event.detail ? event.clientY - box.top : box.height / 2}px`;
      button.append(ripple);
      ripple.addEventListener('animationend', () => ripple.remove(), { once: true });
      setTimeout(() => ripple.remove(), 700);
    });
    observer.observe(button);
  }
  document.querySelectorAll(selector).forEach(enhance);
  document.querySelectorAll('.tour-card, .beam-surface').forEach(card => observer.observe(card));
  // The existing ride finder creates its result action after submission.
  const finder = document.querySelector('#finder-result');
  if (finder) new MutationObserver(() => finder.querySelectorAll(selector).forEach(enhance)).observe(finder, { childList: true });
  reduced.addEventListener('change', () => {
    document.querySelectorAll('.metal-button').forEach(button => {
      if (reduced.matches) dispose(button);
      else if (button.classList.contains('effects-visible')) mountMetal(button);
    });
  });
  window.addEventListener('pagehide', () => mounts.forEach((_, button) => dispose(button)));
  window.addEventListener('pageshow', () => document.querySelectorAll('.metal-button.effects-visible').forEach(mountMetal));
})();
