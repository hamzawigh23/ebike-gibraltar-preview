/* Muted real footage, with an explicit pause control and reduced-motion support. */
(() => {
  'use strict';
  const video = document.querySelector('#hero-film');
  const control = document.querySelector('#hero-playback');
  const hero = document.querySelector('.cinematic-hero');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  if (!video || !control || !hero) return;
  let wantsPlayback = !reduced.matches;
  let visible = true;
  const update = () => {
    const playing = !video.paused;
    const label = playing ? 'Pause background video' : 'Play background video';
    control.setAttribute('aria-label', label);
    control.title = label;
    control.querySelector('use').setAttribute('href', playing ? '#i-pause' : '#i-play');
  };
  const sync = () => {
    if (wantsPlayback && visible && !document.hidden && !document.querySelector('dialog[open]')) {
      video.play().catch(update);
    } else video.pause();
  };
  control.addEventListener('click', () => { wantsPlayback = video.paused; sync(); });
  video.addEventListener('play', update);
  video.addEventListener('pause', update);
  video.addEventListener('error', () => {
    control.disabled = true;
    control.setAttribute('aria-label', 'Background video unavailable');
  });
  new IntersectionObserver(entries => { visible = entries[0].isIntersecting; sync(); }, {threshold:.1}).observe(hero);
  new MutationObserver(sync).observe(document.body, {subtree:true,attributes:true,attributeFilter:['open']});
  reduced.addEventListener('change', () => { wantsPlayback = !reduced.matches; sync(); });
  document.addEventListener('visibilitychange', sync);
  window.addEventListener('pageshow', sync);
  window.addEventListener('pagehide', () => video.pause());
  video.muted = true;
  update();
  sync();
})();
